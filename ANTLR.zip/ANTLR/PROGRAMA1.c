#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

int main(void){
	int Parametro; 
	int Fatorial; 
	float Teste; 
	Parametro = 2;
	if ( Parametro < 0) {
		while ( Fatorial < 10) {
		Fatorial = Fatorial + 1;
	}
	}

	return 0;
}