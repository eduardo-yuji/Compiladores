public abstract class Comando {
    public abstract String geradorCodigo();
}
