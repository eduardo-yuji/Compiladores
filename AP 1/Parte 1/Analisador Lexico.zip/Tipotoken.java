enum TipoToken {
    PCDec, PCProg, PCInt, PCReal, PCLer, PCImprimir, PCSe, PCSenao, PCEntao, PCEnqto, PCIni, PCFim, OpAritMult,
    OpAritDiv, OpAritSoma, OpAritSub, OpRelMenor, OpRelMenorIgual, OpRelMaior, OpRelMaiorIgual, OpRelIgual, OpRelDif,
    OpBoolE, OpBoolOu, IniDelim, FimDelim, Atrib, AbrePar, FechaPar, Var, NumInt, NumReal, Cadeia, EOF
}