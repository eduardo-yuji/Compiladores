
public class ComandoLeitura extends Comando {
	private String id;
	
	
	
	public String getId() {
		return id;
	}



	public void setId(String id) {
		this.id = id;
	}



	public String geradorCodigo() {
		String str=null;
		//implementar
		return str;
	}

}
