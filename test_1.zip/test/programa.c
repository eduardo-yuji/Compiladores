#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

int main() {
	float Parametro2;
	int Parametro;
	int Fatorial;
	return 0; 
}