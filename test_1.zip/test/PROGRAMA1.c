
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

 int main(void){
	float Parametro2; 
	int Parametro; 
	int Fatorial; 

 	return 0;
 }